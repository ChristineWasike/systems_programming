#include <stdio.h>
#include <stdlib.h>

int multiply(int number_a, int number_b){
    return number_a * number_b;
}