#include <stdio.h>
#include <stdlib.h>

int add(int number_a, int number_b){
    return number_a + number_b;
}